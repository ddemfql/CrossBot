"""Streamlit page composition."""
