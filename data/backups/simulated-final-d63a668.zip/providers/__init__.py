﻿"""Model provider adapters."""
